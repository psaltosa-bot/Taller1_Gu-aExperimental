from models import Estudiante, CAMPOS_ESTUDIANTE
from shared.json_manager import GestorJSON
from shared.herramientas import es_email_valido

# CONTROLADOR: gestiona datos y reglas; no contiene print().
gestor = GestorJSON("data/estudiantes.json")

# TUPLAS: configuración fija de campos obligatorios y buscables.
CAMPOS_OBLIGATORIOS = ("nombre", "apellido", "email", "carnet")
CAMPOS_BUSCABLES = ("nombre", "apellido", "email", "carnet")


def emails_registrados(excepto_id=None):
    """CONJUNTO: detectar emails repetidos rápidamente."""
    return {r["email"].lower() for r in gestor.leer() if r["id"] != excepto_id}


def carnets_registrados(excepto_id=None):
    """CONJUNTO: detectar carnets repetidos rápidamente."""
    return {r["carnet"].lower() for r in gestor.leer() if r["id"] != excepto_id}


def siguiente_id():
    # LISTA: los registros del JSON se manejan como una lista.
    ids = [r["id"] for r in gestor.leer()]
    return max(ids) + 1 if ids else 1


def crear_estudiante(datos):
    """CREATE. Devuelve (éxito, mensaje)."""
    try:
        # DICCIONARIO: normaliza los datos antes de crear el objeto.
        valores = {c: str(datos.get(c, "")).strip() for c in CAMPOS_ESTUDIANTE}
        faltantes = [c for c in CAMPOS_OBLIGATORIOS if not valores[c]]
        if faltantes:
            return False, f"Faltan campos obligatorios: {', '.join(faltantes)}"
        if not es_email_valido(valores["email"]):
            return False, f"El email '{valores['email']}' no tiene un formato válido"
        if valores["email"].lower() in emails_registrados():
            return False, "Ese email ya está registrado"
        if valores["carnet"].lower() in carnets_registrados():
            return False, "Ese carnet ya está registrado"

        estudiante = Estudiante(siguiente_id(), **valores)
        registros = gestor.leer()
        registros.append(estudiante.a_diccionario())
        if not gestor.guardar(registros):
            return False, "No se pudo escribir el archivo"
        return True, f"Estudiante {estudiante.obtener_nombre_completo()} creado con id {estudiante.id}"
    except Exception as error:
        return False, f"Error inesperado: {error}"


def obtener_todos():
    """READ. LISTA de objetos Estudiante."""
    return [Estudiante.desde_diccionario(r) for r in gestor.leer()]


def obtener_por_id(id_estudiante):
    for estudiante in obtener_todos():
        if estudiante.id == id_estudiante:
            return estudiante
    return None


def buscar_estudiantes(termino):
    """SEARCH por nombre, apellido, email o carnet."""
    termino = str(termino).strip().lower()
    if not termino:
        return []
    encontrados = []
    for registro in gestor.leer():
        for campo in CAMPOS_BUSCABLES:  # TUPLA de campos permitidos.
            if termino in str(registro.get(campo, "")).lower():
                encontrados.append(Estudiante.desde_diccionario(registro))
                break
    return encontrados


def actualizar_estudiante(id_estudiante, cambios):
    """UPDATE de los campos básicos del estudiante."""
    try:
        desconocidos = set(cambios) - set(CAMPOS_ESTUDIANTE)
        if desconocidos:
            return False, f"Campos no válidos: {', '.join(sorted(desconocidos))}"
        if not cambios:
            return False, "No se indicó ningún cambio"

        cambios = {c: str(v).strip() for c, v in cambios.items()}
        if "email" in cambios:
            if not es_email_valido(cambios["email"]):
                return False, "El email no tiene un formato válido"
            if cambios["email"].lower() in emails_registrados(excepto_id=id_estudiante):
                return False, "Ese email ya lo usa otro estudiante"
        if "carnet" in cambios:
            if not cambios["carnet"]:
                return False, "El carnet no puede quedar vacío"
            if cambios["carnet"].lower() in carnets_registrados(excepto_id=id_estudiante):
                return False, "Ese carnet ya lo usa otro estudiante"

        registros = gestor.leer()
        posicion = next((i for i, r in enumerate(registros) if r["id"] == id_estudiante), None)
        if posicion is None:
            return False, f"No existe un estudiante con id {id_estudiante}"
        registros[posicion].update(cambios)
        if not gestor.guardar(registros):
            return False, "No se pudo escribir el archivo"
        return True, f"Estudiante {id_estudiante} actualizado ({len(cambios)} campo/s)"
    except Exception as error:
        return False, f"Error inesperado: {error}"


def eliminar_estudiante(id_estudiante):
    """DELETE."""
    registros = gestor.leer()
    quedan = [r for r in registros if r["id"] != id_estudiante]  # LISTA nueva.
    if len(quedan) == len(registros):
        return False, f"No existe un estudiante con id {id_estudiante}"
    if not gestor.guardar(quedan):
        return False, "No se pudo escribir el archivo"
    return True, f"Estudiante {id_estudiante} eliminado"


def agregar_nota(id_estudiante, materia, nota):
    """Agrega una nota válida y registra la materia."""
    try:
        materia = str(materia).strip()
        if not materia:
            return False, "La materia no puede estar vacía"
        try:
            nota = float(nota)
        except (TypeError, ValueError):
            return False, "La nota debe ser un número entre 0 y 20"
        if not 0 <= nota <= 20:
            return False, "La nota debe ser un número entre 0 y 20"
        if nota.is_integer():
            nota = int(nota)

        registros = gestor.leer()
        posicion = next((i for i, r in enumerate(registros) if r["id"] == id_estudiante), None)
        if posicion is None:
            return False, f"No existe un estudiante con id {id_estudiante}"

        estudiante = Estudiante.desde_diccionario(registros[posicion])
        estudiante.agregar_nota(materia, nota)
        registros[posicion] = estudiante.a_diccionario()
        if not gestor.guardar(registros):
            return False, "No se pudo escribir el archivo"
        return True, f"Nota {nota}/20 agregada en {materia} al estudiante {id_estudiante}"
    except Exception as error:
        return False, f"Error inesperado: {error}"


def obtener_promedio(id_estudiante):
    estudiante = obtener_por_id(id_estudiante)
    return None if estudiante is None else estudiante.obtener_promedio()


def materias_ofertadas():
    """SET: unión de materias de todos los estudiantes, sin repetir."""
    materias = set()
    for estudiante in obtener_todos():
        materias.update(estudiante.materias)
    return materias


def estudiantes_en_comun(id_a, id_b):
    """SET: intersección de las materias de dos estudiantes."""
    a, b = obtener_por_id(id_a), obtener_por_id(id_b)
    if a is None or b is None:
        return None
    return a.materias_en_comun(b)
