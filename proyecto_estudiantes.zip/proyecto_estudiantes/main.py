from models import CAMPOS_ESTUDIANTE
from shared.herramientas import imprimir_titulo, imprimir_exito, imprimir_error, imprimir_info, confirmar
from views import (
    crear_estudiante, obtener_todos, obtener_por_id, buscar_estudiantes,
    actualizar_estudiante, eliminar_estudiante, agregar_nota,
    materias_ofertadas, estudiantes_en_comun
)


def pausa():
    input("\nPresione Enter para continuar...")


def mostrar_tabla(estudiantes):
    print(f"{'ID':<5}{'NOMBRE':<25}{'EMAIL':<28}{'CARNET':<15}{'PROMEDIO':<10}")
    print("-" * 83)
    for e in estudiantes:
        print(f"{e.id:<5}{e.obtener_nombre_completo():<25}{e.email:<28}{e.carnet:<15}{e.obtener_promedio():<10}")
    print("-" * 83)
    imprimir_info(f"Total: {len(estudiantes)} estudiante(s)")


def opcion_crear():
    imprimir_titulo("CREAR NUEVO ESTUDIANTE")
    datos = {campo: input(f"{campo.capitalize()}: ") for campo in CAMPOS_ESTUDIANTE}
    exito, mensaje = crear_estudiante(datos)
    imprimir_exito(mensaje) if exito else imprimir_error(mensaje)
    pausa()


def opcion_ver_todos():
    imprimir_titulo("LISTA DE ESTUDIANTES")
    estudiantes = obtener_todos()
    if not estudiantes:
        imprimir_info("Todavía no hay estudiantes. Use la opción 1 para crear el primero.")
    else:
        mostrar_tabla(estudiantes)
    pausa()


def opcion_buscar():
    imprimir_titulo("BUSCAR ESTUDIANTE")
    termino = input("Nombre, apellido, email o carnet: ")
    encontrados = buscar_estudiantes(termino)
    if not encontrados:
        imprimir_info(f"Ningún estudiante coincide con '{termino}'.")
    else:
        mostrar_tabla(encontrados)
    pausa()


def opcion_ver_por_id():
    imprimir_titulo("VER ESTUDIANTE POR ID")
    try:
        id_estudiante = int(input("Id del estudiante: "))
    except ValueError:
        imprimir_error("El id debe ser un número entero")
        return pausa()
    e = obtener_por_id(id_estudiante)
    if not e:
        imprimir_error(f"No existe un estudiante con id {id_estudiante}")
    else:
        print(f"  Nombre completo : {e.obtener_nombre_completo()}")
        print(f"  Email           : {e.email}")
        print(f"  Carnet          : {e.carnet}")
        print(f"  Materias        : {', '.join(sorted(e.materias)) or 'Ninguna'}")
        print(f"  Notas           : {e.notas}")
        print(f"  Promedio        : {e.obtener_promedio()}")
    pausa()


def opcion_actualizar():
    imprimir_titulo("ACTUALIZAR ESTUDIANTE")
    try:
        id_estudiante = int(input("Id del estudiante: "))
    except ValueError:
        imprimir_error("El id debe ser un número entero")
        return pausa()
    e = obtener_por_id(id_estudiante)
    if not e:
        imprimir_error(f"No existe un estudiante con id {id_estudiante}")
        return pausa()
    imprimir_info(f"Editando a {e.obtener_nombre_completo()}")
    print("Deje en blanco el campo que no quiera cambiar.\n")
    cambios = {}
    for campo in CAMPOS_ESTUDIANTE:
        nuevo = input(f"{campo.capitalize()} [{getattr(e, campo)}]: ").strip()
        if nuevo:
            cambios[campo] = nuevo
    exito, mensaje = actualizar_estudiante(id_estudiante, cambios)
    imprimir_exito(mensaje) if exito else imprimir_error(mensaje)
    pausa()


def opcion_eliminar():
    imprimir_titulo("ELIMINAR ESTUDIANTE")
    try:
        id_estudiante = int(input("Id del estudiante: "))
    except ValueError:
        imprimir_error("El id debe ser un número entero")
        return pausa()
    e = obtener_por_id(id_estudiante)
    if not e:
        imprimir_error(f"No existe un estudiante con id {id_estudiante}")
        return pausa()
    imprimir_info(f"Se eliminará: {e}")
    if confirmar("¿Confirma la eliminación?"):
        exito, mensaje = eliminar_estudiante(id_estudiante)
        imprimir_exito(mensaje) if exito else imprimir_error(mensaje)
    else:
        imprimir_info("Operación cancelada")
    pausa()


def opcion_agregar_nota():
    imprimir_titulo("AGREGAR NOTA")
    try:
        id_estudiante = int(input("Id del estudiante: "))
    except ValueError:
        imprimir_error("El id debe ser un número entero")
        return pausa()
    materia = input("Materia: ").strip()
    try:
        nota = float(input("Nota (0 a 20): "))
    except ValueError:
        imprimir_error("La nota debe ser un número entre 0 y 20")
        return pausa()
    exito, mensaje = agregar_nota(id_estudiante, materia, nota)
    imprimir_exito(mensaje) if exito else imprimir_error(mensaje)
    pausa()


def opcion_ver_promedio():
    imprimir_titulo("VER PROMEDIO")
    try:
        id_estudiante = int(input("Id del estudiante: "))
    except ValueError:
        imprimir_error("El id debe ser un número entero")
        return pausa()
    e = obtener_por_id(id_estudiante)
    if not e:
        imprimir_error(f"No existe un estudiante con id {id_estudiante}")
    else:
        imprimir_info(f"Promedio de {e.obtener_nombre_completo()}: {e.obtener_promedio()}/20")
    pausa()


def opcion_materias_ofertadas():
    imprimir_titulo("MATERIAS OFERTADAS")
    materias = materias_ofertadas()
    if not materias:
        imprimir_info("Todavía no hay materias inscritas.")
    else:
        print("Materias inscritas por todos los estudiantes:")
        for materia in sorted(materias):
            print(f"  - {materia}")
    pausa()


def opcion_materias_comun():
    imprimir_titulo("MATERIAS EN COMÚN")
    try:
        id_a = int(input("Id del primer estudiante: "))
        id_b = int(input("Id del segundo estudiante: "))
    except ValueError:
        imprimir_error("Los ids deben ser números enteros")
        return pausa()
    a, b = obtener_por_id(id_a), obtener_por_id(id_b)
    if not a or not b:
        imprimir_error("Uno o ambos ids no existen")
    else:
        comunes = estudiantes_en_comun(id_a, id_b)
        if comunes:
            imprimir_info(f"Materias en común: {', '.join(sorted(comunes))}")
        else:
            imprimir_info("Los estudiantes no tienen materias en común.")
    pausa()


def salir():
    imprimir_info("¡Hasta luego! 👋")
    return "salir"


# DICCIONARIO: tecla -> (texto del menú, función).
OPCIONES = {
    "1": ("Crear estudiante", opcion_crear),
    "2": ("Ver todos", opcion_ver_todos),
    "3": ("Buscar", opcion_buscar),
    "4": ("Ver por id", opcion_ver_por_id),
    "5": ("Actualizar", opcion_actualizar),
    "6": ("Eliminar", opcion_eliminar),
    "7": ("Agregar nota", opcion_agregar_nota),
    "8": ("Ver promedio", opcion_ver_promedio),
    "9": ("Materias ofertadas", opcion_materias_ofertadas),
    "10": ("Materias en común", opcion_materias_comun),
    "0": ("Salir", salir),
}


def mostrar_menu():
    imprimir_titulo("SISTEMA DE GESTIÓN DE ESTUDIANTES")
    for tecla, (texto, _funcion) in OPCIONES.items():
        print(f"  {tecla}. {texto}")
    print()


def main():
    while True:
        mostrar_menu()
        tecla = input("Seleccione una opción: ").strip()
        if tecla not in OPCIONES:
            imprimir_error("Opción no válida")
            pausa()
            continue
        _texto, funcion = OPCIONES[tecla]
        if funcion() == "salir":
            break


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nPrograma interrumpido por el usuario.")
