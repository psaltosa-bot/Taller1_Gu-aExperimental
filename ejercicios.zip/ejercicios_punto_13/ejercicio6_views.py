# EJERCICIO 6 - AGREGAR AL CONTROLADOR (views.py)
#
# Esta función está pensada para agregarse al archivo views.py
# del proyecto de la guía, donde ya existe el objeto global "gestor".

def clientes_por_ciudad():
    """Agrupa los clientes por ciudad y devuelve un diccionario."""
    agrupados = {}

    for registro in gestor.leer():
        ciudad = registro.get("ciudad", "").title() or "Sin ciudad"

        # Si la ciudad todavía no existe, setdefault crea una lista vacía.
        # Luego agregamos el nombre del cliente a esa lista.
        agrupados.setdefault(ciudad, []).append(registro["nombre"])

    return agrupados


# Ejemplo de cómo mostrar el resultado desde main.py:
#
# agrupados = clientes_por_ciudad()
# for ciudad, nombres in agrupados.items():
#     print(f"{ciudad}: {', '.join(nombres)}")
