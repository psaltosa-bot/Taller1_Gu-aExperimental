# EJERCICIOS DEL PUNTO 13 - GUIA CRUD PYTHON
# Soluciones de los ejercicios 1 al 5

print("=" * 60)
print("EJERCICIO 1 - QUITAR DUPLICADOS CONSERVANDO EL ORDEN")
print("=" * 60)

ciudades = ["Quito", "Guayaquil", "Quito", "Cuenca", "Guayaquil"]

vistas = set()
unicas = []

for ciudad in ciudades:
    if ciudad not in vistas:
        vistas.add(ciudad)
        unicas.append(ciudad)

print("Lista original:", ciudades)
print("Lista sin repetidos:", unicas)
print()


print("=" * 60)
print("EJERCICIO 2 - CONTAR CON UN DICCIONARIO")
print("=" * 60)

conteo = {}

for ciudad in ciudades:
    conteo[ciudad] = conteo.get(ciudad, 0) + 1

print("Conteo:", conteo)

mas_repetida = max(conteo, key=conteo.get)
print("Ciudad más repetida:", mas_repetida)
print()


print("=" * 60)
print("EJERCICIO 3 - CONJUNTOS EN ACCIÓN")
print("=" * 60)

inscritos_matematica = {"Ana", "Luis", "Sol", "Marco"}
inscritos_ingles = {"Luis", "Marco", "Ruth"}

ambas = inscritos_matematica & inscritos_ingles
solo_mate = inscritos_matematica - inscritos_ingles
total = len(inscritos_matematica | inscritos_ingles)

print("Estudiantes en las dos materias:", sorted(ambas))
print("Solo en Matemática:", sorted(solo_mate))
print("Cantidad de estudiantes distintos:", total)
print()


print("=" * 60)
print("EJERCICIO 4 - DE LISTA DE DICCIONARIOS A ÍNDICE")
print("=" * 60)

clientes = [
    {"id": 1, "nombre": "Ana"},
    {"id": 2, "nombre": "Luis"}
]

indice = {cliente["id"]: cliente for cliente in clientes}

print("Índice:", indice)
print("Nombre del cliente con id 2:", indice[2]["nombre"])
print()


print("=" * 60)
print("EJERCICIO 5 - TUPLAS COMO REGISTROS INMUTABLES")
print("=" * 60)

ventas = [
    ("enero", 1500),
    ("febrero", 1800),
    ("marzo", 1200)
]

total = sum(monto for _mes, monto in ventas)
mejor_mes, mejor_monto = max(ventas, key=lambda venta: venta[1])

print(f"Total: {total}")
print(f"Mejor mes: {mejor_mes} con {mejor_monto}")

print("\nVentas:")
for mes, monto in ventas:
    print(f"{mes:<10} {monto}")
