# Soluciones - Punto 13 de la Guía CRUD en Python

Este ZIP contiene las soluciones de los 6 ejercicios del apartado 13
"Ejercicios de colecciones" de la guía proporcionada.

## Archivos

- `practica.py`
  - Ejercicio 1: quitar duplicados conservando el orden.
  - Ejercicio 2: contar elementos con un diccionario.
  - Ejercicio 3: operaciones con conjuntos.
  - Ejercicio 4: crear un índice con un diccionario.
  - Ejercicio 5: trabajar con tuplas y desempaquetado.

- `ejercicio6_views.py`
  - Ejercicio 6: función `clientes_por_ciudad()` para agregar al Controlador (`views.py`).

## Ejecutar

Desde una terminal, dentro de esta carpeta:

    python practica.py

El ejercicio 6 no se ejecuta de forma independiente porque utiliza el objeto
`gestor` que ya existe en el proyecto principal de la guía. Su función debe
copiarse dentro de `views.py`.

## Nota

Las soluciones siguen la lógica indicada en el punto 13 de la guía.
